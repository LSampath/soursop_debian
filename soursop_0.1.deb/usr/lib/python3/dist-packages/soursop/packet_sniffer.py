import logging
from datetime import datetime
from threading import Thread

import psutil
from scapy.layers.inet import IP, TCP, UDP
from scapy.layers.inet6 import IPv6
from scapy.sendrecv import sniff

from soursop import util
from soursop.process_handler import get_process_info
from soursop.utility_monitor import get_wifi_ips, start_utility_monitor, get_connection_pid


# dictionary to map each pid_name to packet details
# _TRAFFIC_MAP = dict[str, PacketInfo]
# _TRAFFIC_MAP_LOCK = Lock()

# # dataframe to track previous traffic usages
# PREVIOUS_USAGES = None

# _THREAD_POOL = ThreadPoolExecutor(max_workers=3)


def get_packet_connection(packet) -> tuple | None:
    try:
        if IP in packet:
            ip_packet = packet[IP]
            src_ip, dst_ip = ip_packet.src, ip_packet.dst
        elif IPv6 in packet:
            ipv6_packet = packet[IPv6]
            src_ip, dst_ip = ipv6_packet.src, ipv6_packet.dst
        else:
            return None

        if TCP in packet:
            tcp_packet = packet[TCP]
            src_port, dst_port = tcp_packet.sport, tcp_packet.dport
        elif UDP in packet:
            udp_packet = packet[UDP]
            src_port, dst_port = udp_packet.sport, udp_packet.dport
        else:
            return None

        return src_port, dst_port, src_ip, dst_ip
    except (AttributeError, IndexError):
        return None


def process_packet(packet):
    """
    find destination and source ports of each packet to determine which connection this packet belongs
    and update the CONNECTION_PID_MAP
    """
    # global _PID_TRAFFIC_MAP
    wifi_ip_set = get_wifi_ips()
    packet_connection_info = get_packet_connection(packet)

    if packet_connection_info:
        src_port, dst_port, src_ip, dst_ip = packet_connection_info
        packet_pid = get_connection_pid((src_port, dst_port))

        if packet_pid:
            process_info = get_process_info(packet_pid)
            if src_ip and src_ip in wifi_ip_set:
                process_info["outgoing"] += len(packet)  # outgoing/upload
            elif dst_ip and dst_ip in wifi_ip_set:
                process_info["incoming"] += len(packet)  # incoming/download
            print(process_info)
            logging.info(process_info)


# def process_packet_async(packet) -> None:
#     _THREAD_POOL.submit(process_packet, packet)


def sniff_packets() -> None:
    logging.info("started sniffing thread")
    sniff(prn=process_packet, store=False, filter="(ip or ip6) and (tcp or udp)", stop_filter=lambda _: not util.RUNNING_FLAG)
    logging.info("Stopped sniffing thread")


# def calculate_and_save_usage():
#     global PREVIOUS_USAGES
#     process_info_map = {}
#     for pid, (up_traffic, down_traffic) in _PID_TRAFFIC_MAP.items():
#         try:
#             process = psutil.Process(pid)
#         except psutil.NoSuchProcess:
#             continue
#         name = process.name()
#         create_time = get_process_create_time(process)
#         process_info = {
#             "pid": pid, "name": name, "create_time": create_time,
#             "Upload": up_traffic, "Download": down_traffic,
#         }
#         process_info_map[pid] = process_info
#
#     print_stats(process_info_map)
#
#     PREVIOUS_USAGES = process_info_map


# def print_stats(process_info_map):
#     for pid, process_info in process_info_map.items():
#         logging.info(process_info)
#         print(process_info)
# os.system("clear")


def get_process_create_time(process):
    try:
        create_time = datetime.fromtimestamp(process.create_time())
    except OSError:
        create_time = datetime.fromtimestamp(psutil.boot_time())
    return create_time


# def save_usages():
#     logging.info("Started usage saving thread....")
#     # while config.RUNNING_FLAG:
#     while True:
#         calculate_and_save_usage()
#         sleep(1)
#     logging.info("Stopped usage saving thread.....")


def start_packet_sniffing():
    sniff_thread = Thread(target=sniff_packets, daemon=False)  # why not daemon ????
    sniff_thread.start()

    # save_usage_thread = Thread(target=save_usages, daemon=True)
    # save_usage_thread.start()


# remove later
if __name__ == "__main__":
    print("Starting soursop daemon service..... using main method")
    start_utility_monitor()
    start_packet_sniffing()

# TODO list
# make sure this shutdown gracefully, when daemon is shutting down
# make sure things are thread safe
# think about the usage frequency, may be calculation frequency is good enough, saving frequency can be slower
