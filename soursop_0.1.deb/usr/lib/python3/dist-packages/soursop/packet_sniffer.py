from collections import defaultdict
from threading import Thread
from time import sleep

import psutil
from scapy.interfaces import ifaces
from scapy.sendrecv import sniff

from soursop import config

# MAC addresses of every network adapter
ALL_MACS = {iface.mac for iface in ifaces.values()}

# A dictionary to map each connection to its corresponding process ID (PID)
CONNECTION_PID_MAP = {}

# A dictionary to map each process ID (PID) to total Upload (0) and Download (1) traffic
PID_TRAFFIC_MAP = defaultdict(lambda: [0, 0])


def process_packet(packet):
    """
    find destination and source ports of each packet to determine which connection this packet belongs
    and update the CONNECTION_PID_MAP
    """
    global PID_TRAFFIC_MAP
    try:
        packet_connection = (packet.sport, packet.dport)
    except (AttributeError, IndexError):
        # print("sometimes the packet does not have TCP/UDP layers, we just ignore these packets")
        pass
    else:
        print("we are processing this packet $$$$$$")
        packet_pid = CONNECTION_PID_MAP.get(packet_connection)
        if packet_pid:
            if packet.src in ALL_MACS:
                PID_TRAFFIC_MAP[packet_pid][0] += len(packet)  # outgoing/upload
            else:
                PID_TRAFFIC_MAP[packet_pid][1] += len(packet)  # incoming/download


def get_connections():
    """
    Keeps listening for connections on this machine, and add them to global CONNECTION_PID_MAP
    (local_address.port, remove_address.port) -> pid
    """
    print("Start connection updating thread....")
    global CONNECTION_PID_MAP
    while config.RUNNING_FLAG:
        for c in psutil.net_connections():
            if c.laddr and c.raddr and c.pid:
                CONNECTION_PID_MAP[(c.laddr.port, c.raddr.port)] = c.pid
                CONNECTION_PID_MAP[(c.raddr.port, c.laddr.port)] = c.pid
        sleep(1)
    print("stopped connection updating thread...")


def sniff_packets():
    print("started sniffing thread.....")
    sniff(prn=process_packet, store=False, stop_filter=lambda _: not config.RUNNING_FLAG)
    print("Stopped sniffing thread...")


def start_packet_sniffing():
    sniff_thread = Thread(target=sniff_packets, daemon=False)
    sniff_thread.start()

    connections_thread = Thread(target=get_connections, daemon=True)
    connections_thread.start()
