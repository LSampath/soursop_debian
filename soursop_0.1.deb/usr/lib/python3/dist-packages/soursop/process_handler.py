from datetime import datetime

import psutil


def get_process_create_time(process):
    try:
        create_time = datetime.fromtimestamp(process.create_time())
    except OSError:
        create_time = datetime.fromtimestamp(psutil.boot_time())
    return create_time


def get_process_info(pid: int) -> dict | None:
    try:
        p = psutil.Process(pid)
        with p.oneshot():
            create_time = p.create_time()
            name = p.name()
            path = p.exe()
        info = {
            "create_time": create_time,
            "name": name,
            "pid": pid,
            "path": path,
            "incoming": 0,
            "outgoing": 0
        }
        return info
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None
